package com.example.convertdistance;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonKmToM = (Button) findViewById(R.id.buttonKmToM);
        buttonKmToM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText km = (EditText) findViewById(R.id.editTextKm);
                EditText miles = (EditText) findViewById(R.id.editTextM);
                double vKm = Double.parseDouble(km.getText().toString());
                double vM = vKm * 0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.###");
                miles.setText(formatVal.format(vM));
            }

        });
        Button buttonMtoKm = (Button) findViewById(R.id.buttonMToKm);
        buttonMtoKm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText km = (EditText) findViewById(R.id.editTextKm);
                EditText miles = (EditText) findViewById(R.id.editTextM);
                double vM = Double.parseDouble(miles.getText().toString());
                double vKm = vM / 0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.###");
                km.setText(formatVal.format(vKm));
            }

        });


    }
}